const express = require('express');
const mongoose = require('mongoose');
const sinhvien = require('./sinhvienModel');

const app = express();
mongoose.connect('mongodb://localhost:27017/AND103', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log("Da Ket Noi Thanh Cong Voi MongoDB");
}).catch((err) => {
    console.error(err);
});

app.get('/sinhvien', async (req, res) => {
    try{
        const sinhviens = await sinhvien.find();
        res.json(sinhviens);
        console.log(sinhviens);
    }
    catch(err) {
        console.error(err);
        res.status(500).json({error:'Internel Server Error'});
    }
});

const PORT = process.env.PORT||3000;
app.listen(PORT, () => {
    console.log('Server Dang Chay O Cong 3000');
})