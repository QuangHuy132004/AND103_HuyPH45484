package com.example.lab1_ph45484.Demo5.select;

import com.example.lab1_ph45484.Demo5.SanPham;

public class SvrResponseSelect {
    private SanPham[] products;
    private String message;

    public SanPham[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
