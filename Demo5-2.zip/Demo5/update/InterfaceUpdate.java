package com.example.lab1_ph45484.Demo5.update;

import com.example.lab1_ph45484.Demo5.SvResponseSanPham;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceUpdate {
    @FormUrlEncoded
    @POST("update.php")
    Call<SvResponseSanPham> updateSanPham(
            @Field("MaSP") String MaSP,
            @Field("TenSP") String TenSP,
            @Field("Mota") String Mota
    );
}
