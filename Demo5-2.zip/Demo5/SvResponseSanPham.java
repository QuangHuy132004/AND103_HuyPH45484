package com.example.lab1_ph45484.Demo5;

public class SvResponseSanPham {
    //ket qua tra ve
    private SanPham sanphams;
    private String message;

    public SanPham getSanphams() {
        return sanphams;
    }

    public String getMessage() {
        return message;
    }
}
