package com.example.lab1_ph45484.Demo5;

import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface InterfaceinsertSanPham {
    @FormUrlEncoded
    @POST("insert2.php")
    Call<SvResponseSanPham> insertSanPham(
            @Field("MaSP") String MaSP,
            @Field("TenSP") String TenSP,
            @Field("MoTa") String Mota
    );
}
