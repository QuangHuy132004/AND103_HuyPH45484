//npm i nodemailer
//import thu vien
const express=require('express');
const mailer=require('nodemailer');
const app43=express();//tao doi tuong express
//tao thong tin nguoi gui
let transporter=mailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'nguyenquanghung.bkhn@gmail.com',
        pass: 'lkai wdan sqea ueuw'
    }
});
//noi dung can gui
let mailOption={
    from: 'nguyenquanghung.bkhn@gmail.com',
    to: 'huynqph45484@fpt.edu.vn',
    subject: 'FECREDIT',
    text: '"CO VAY CO TRA" Chung toi chi muon DOI DUOC NO khong muon XO XAT gay thuong tich. Vi the tin nhan nay la vo cung thien chi. Yeu cau: Ong/Ba PHAM TUAN DAT ra thanh toan gap khoan no 70,000,000 vay tu phia CTY TAI CHINH FECREDIT dang nhac nho. Truoc 14H NGAY 17/7/2024 neu khong hop tac hoac ngoan co khong tra no, loi le khieu khich, thach thuc. CHUNG TOI KHONG DAM BAO DANH DU, THIET HAI NAO CHO BAT KY 1 AI. Dung de moi chuyen di qua xa dan den HAU QUA NGHIEM TRONG.'
};
//thuc hien gui
transporter.sendMail(mailOption,(error,info)=>{
    if(error){
        console.error(error);
    }
    else{
        console.log("Thanh cong: ",info.messageId);
    }
});
//lang nghe
app43.listen(3002,()=>{
    console.log("server dang chay o cong 3002");
});