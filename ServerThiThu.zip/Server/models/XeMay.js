const mongoose = require('mongoose');

const xeMaySchema = new mongoose.Schema({
    ten_xe_ph45484: { type: String, required: true },
    mau_sac_ph45484: { type: String, required: true },
    gia_ban_ph45484: { type: Number, required: true },
    mo_ta_ph45484: { type: String },
    hinh_anh_ph45484: { type: String }
});

module.exports = mongoose.model('xemays', xeMaySchema);
