const express = require('express');
const router = express.Router();
const XeMay = require('../models/XeMay');

// Lấy tất cả xe máy
router.get('/', async (req, res) => {
    try {
        const xeMays = await XeMay.find();
        res.json(xeMays);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Thêm xe máy mới
router.post('/', async (req, res) => {
    const xeMay = new XeMay({
        ten_xe_ph45484: req.body.ten_xe_ph45484,
        mau_sac_ph45484: req.body.mau_sac_ph45484,
        gia_ban_ph45484: req.body.gia_ban_ph45484,
        mo_ta_ph45484: req.body.mo_ta_ph45484,
        hinh_anh_ph45484: req.body.hinh_anh_ph45484
    });
    try {
        const newXeMay = await xeMay.save();
        res.status(201).json(newXeMay);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Cập nhật thông tin xe máy
router.put('/:id', async (req, res) => {
    try {
        const xeMay = await XeMay.findById(req.params.id);
        if (!xeMay) return res.status(404).json({ message: 'Không tìm thấy xe máy' });

        xeMay.ten_xe_ph45484 = req.body.ten_xe_ph45484;
        xeMay.mau_sac_ph45484 = req.body.mau_sac_ph45484;
        xeMay.gia_ban_ph45484 = req.body.gia_ban_ph45484;
        xeMay.mo_ta_ph45484 = req.body.mo_ta_ph45484;
        xeMay.hinh_anh_ph45484 = req.body.hinh_anh_ph45484;

        const updatedXeMay = await xeMay.save();
        res.json(updatedXeMay);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Xóa xe máy

router.delete('/:id', async (req, res) => {
    try {
        const xeMay = await XeMay.findById(req.params.id);
        if (!xeMay) return res.status(404).json({ message: 'Không tìm thấy xe máy' });

        // Sử dụng phương thức findByIdAndDelete để xóa tài liệu
        await XeMay.findByIdAndDelete(req.params.id);
        res.json({ message: 'Đã xóa xe máy' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Tìm kiếm xe máy theo tên
// router.get('/search', async (req, res) => {
//     try {
//         const query = req.query.ten_xe_ph45160;
//         const xeMays = await XeMay.find({ ten_xe_ph45160: new RegExp(query, 'i') });
//         res.json(xeMays);
//     } catch (err) {
//         res.status(500).json({ message: err.message });
//     }
// });

module.exports = router;
