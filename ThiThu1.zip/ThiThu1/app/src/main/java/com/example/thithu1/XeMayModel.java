package com.example.thithu1;

public class XeMayModel {
    private String _id;
    private String ten_xe_ph45484;
    private String mau_sac_ph45484;
    private double gia_ban_ph45484;
    private String mo_ta_ph45484;
    private String hinh_anh_ph45484;

    public XeMayModel(String _id,String ten_xe_ph45484, String mau_sac_ph45484, double gia_ban_ph45484, String mo_ta_ph45484, String hinh_anh_ph45484) {
        this.ten_xe_ph45484 = ten_xe_ph45484;
        this.mau_sac_ph45484 = mau_sac_ph45484;
        this.gia_ban_ph45484 = gia_ban_ph45484;
        this.mo_ta_ph45484 = mo_ta_ph45484;
        this.hinh_anh_ph45484 = hinh_anh_ph45484;
    }

    public XeMayModel(String ten_xe_ph45484, String mau_sac_ph45484, double gia_ban_ph45484, String mo_ta_ph45484, String hinh_anh_ph45484) {
        this.ten_xe_ph45484 = ten_xe_ph45484;
        this.mau_sac_ph45484 = mau_sac_ph45484;
        this.gia_ban_ph45484 = gia_ban_ph45484;
        this.mo_ta_ph45484 = mo_ta_ph45484;
        this.hinh_anh_ph45484 = hinh_anh_ph45484;
    }

    public XeMayModel() {
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getTen_xe_ph45484() {
        return ten_xe_ph45484;
    }

    public void setTen_xe_ph45484(String ten_xe_ph45484) {
        this.ten_xe_ph45484 = ten_xe_ph45484;
    }

    public String getMau_sac_ph45484() {
        return mau_sac_ph45484;
    }

    public void setMau_sac_ph45484(String mau_sac_ph45484) {
        this.mau_sac_ph45484 = mau_sac_ph45484;
    }

    public double getGia_ban_ph45484() {
        return gia_ban_ph45484;
    }

    public void setGia_ban_ph45484(double gia_ban_ph45484) {
        this.gia_ban_ph45484 = gia_ban_ph45484;
    }

    public String getMo_ta_ph45484() {
        return mo_ta_ph45484;
    }

    public void setMo_ta_ph45484(String mo_ta_ph45484) {
        this.mo_ta_ph45484 = mo_ta_ph45484;
    }

    public String getHinh_anh_ph45484() {
        return hinh_anh_ph45484;
    }

    public void setHinh_anh_ph45484(String hinh_anh_ph45484) {
        this.hinh_anh_ph45484 = hinh_anh_ph45484;
    }
}
